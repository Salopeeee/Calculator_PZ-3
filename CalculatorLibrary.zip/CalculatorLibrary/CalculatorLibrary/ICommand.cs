﻿using CalculatorLibrary;

public interface ICommand
{
    void Execute(ICalculatorCommands calculator);
}