﻿using CalculatorLibrary;
using System.Collections.Generic;
using System.Text;

public class Calculator : ICalculatorCommands
{
    List<string> result = new List<string>();

    public void BeginSequence()
    {
        result.Clear();
    }
    public double EndSequence()
    {
        StringBuilder Result = new StringBuilder();
        foreach (string item in result)
        {
            Result.Append(item + " ");
        }
        var temp = InfixToRPNConverter.ConvertToRPN(Result.ToString().Trim());
        return ReversePolishNotationCalculator.Evaluate(temp);
    }

    public void Add(double number)
    {
        if (result.Count == 0)
        {
            result.Add(number.ToString());
        }
        else
        {
            result.Add(" + " + number);
        }
    }
    public void Subtract(double number)
    {
        if (result.Count == 0)
        {
            result.Add((-number).ToString());
        }
        else
        {
            result.Add(" - " + number);
        }
    }
    public void Multiply(double number)
    {
        if (result.Count == 0)
        {
            result.Add(number.ToString());
        }
        else
        {
            result.Add(" * " + number);
        }
    }
    public void Divide(double number)
    {
        if (result.Count == 0)
        {
            result.Add(number.ToString());
        }
        else
        {
            result.Add(" / " + number);
        }
    }
    public void ParenthesisOpen(char ch)
    {
        if (result.Count == 0)
        {
            result.Add(ch.ToString());
        }
        else
        {
            string lastElement = result[result.Count - 1];
            int indexOfSpace = lastElement.LastIndexOf(' ');
            string operatorPart = lastElement.Substring(0, indexOfSpace + 1);
            string numberPart = lastElement.Substring(indexOfSpace + 1);
            result[result.Count - 1] = operatorPart + ch + numberPart;
        }
    }
    public void ParenthesisClose(char ch)
    {
        result.Add(ch.ToString());
    }
}
