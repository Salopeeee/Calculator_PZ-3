﻿using System.Text;

namespace CalculatorLibrary
{
    public class CalculatorCommands
    {
        public class AddCommand : ICommand
        {
            private double _operand;

            public AddCommand(double operand)
            {
                _operand = operand;
            }

            public void Execute(ICalculatorCommands calculator)
            {
                calculator.Add(_operand);
            }
        }
        public class SubtractCommand : ICommand
        {
            private double _operand;

            public SubtractCommand(double operand)
            {
                _operand = operand;
            }

            public void Execute(ICalculatorCommands calculator)
            {
                calculator.Subtract(_operand);
            }
        }
        public class MultiplyCommand : ICommand
        {
            private double _operand;

            public MultiplyCommand(double operand)
            {
                _operand = operand;
            }

            public void Execute(ICalculatorCommands calculator)
            {
                calculator.Multiply(_operand);
            }
        }
        public class DivideCommand : ICommand
        {
            private double _operand;

            public DivideCommand(double operand)
            {
                _operand = operand;
            }

            public void Execute(ICalculatorCommands calculator)
            {
                calculator.Divide(_operand);
            }
        }
        public class ParenthesisOpenCommand : ICommand
        {
            private char _char;

            public ParenthesisOpenCommand(char ch)
            {
                _char = ch;
            }
            public void Execute(ICalculatorCommands calculator)
            {
                calculator.ParenthesisOpen(_char);
            }
        }
        public class ParenthesisCloseCommand : ICommand
        {
            private char _char;

            public ParenthesisCloseCommand(char ch)
            {
                _char = ch;
            }
            public void Execute(ICalculatorCommands calculator)
            {
                calculator.ParenthesisClose(_char);
            }
        }
    }
}