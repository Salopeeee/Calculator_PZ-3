﻿namespace CalculatorLibrary
{
    public interface ICalculatorCommands
    {
        void BeginSequence();
        double EndSequence();
        void Add(double number);
        void Subtract(double number);
        void Multiply(double number);
        void Divide(double number);
        void ParenthesisOpen(char ch);
        void ParenthesisClose(char ch);
    }
}