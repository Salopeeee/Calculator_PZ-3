﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using CalculatorLibrary;
using static CalculatorLibrary.CalculatorCommands;

namespace CalculatorLibrary_Tests
{
    [TestClass]
    public class CalculatorLibrary_Test
    {
        /// <summary>
        ///    1
        /// </summary>

        [TestMethod]
        public void Test_Addition()
        {
            var calculator = new Calculator();
            calculator.BeginSequence();
            var addCommand = new AddCommand(3.0);
            addCommand.Execute(calculator);
            Assert.AreEqual(3.0, calculator.EndSequence(), "Subtraction is not correct");
        }

        [TestMethod]
        public void Test_Subtraction()
        {
            var calculator = new Calculator();
            calculator.BeginSequence();
            var subtractCommand = new SubtractCommand(3.0);
            subtractCommand.Execute(calculator);
            Assert.AreEqual(-3.0, calculator.EndSequence(), "Subtraction is not correct");
        }

        [TestMethod]
        public void Test_Multiplication()
        {
            var calculator = new Calculator();
            calculator.BeginSequence();
            var multiplyCommand = new MultiplyCommand(3.0);
            multiplyCommand.Execute(calculator);
            Assert.AreEqual(3.0, calculator.EndSequence(), "Multiplication is not correct");
        }

        [TestMethod]
        public void Test_Division()
        {
            var calculator = new Calculator();
            calculator.BeginSequence();
            var divideCommand = new DivideCommand(2.0);
            divideCommand.Execute(calculator);
            Assert.AreEqual(2.0, calculator.EndSequence(), "Division is not correct");
        }




        /// <summary>
        ///     2
        /// </summary>

        [TestMethod]
        public void Test_Addition_Addition()
        {
            var calculator = new Calculator();
            calculator.BeginSequence();
            var addCommand1 = new AddCommand(5.0);
            var addCommand2 = new AddCommand(3.0);
            addCommand1.Execute(calculator);
            addCommand2.Execute(calculator);
            Assert.AreEqual(8.0, calculator.EndSequence(), "Addition result is not correct");
        }

        [TestMethod]
        public void Test_Subtraction_Subtraction()
        {
            var calculator = new Calculator();
            calculator.BeginSequence();
            var subtractCommand1 = new SubtractCommand(2.0);
            var subtractCommand2 = new SubtractCommand(3.0);
            subtractCommand1.Execute(calculator);
            subtractCommand2.Execute(calculator);
            Assert.AreEqual(-5.0, calculator.EndSequence(), "Subtraction result is not correct");
        }

        [TestMethod]
        public void Test_Multiplication_Multiplication()
        {
            var calculator = new Calculator();
            calculator.BeginSequence();
            var multiplyCommand1 = new MultiplyCommand(7.0);
            var multiplyCommand2 = new MultiplyCommand(3.0);
            multiplyCommand1.Execute(calculator);
            multiplyCommand2.Execute(calculator);
            Assert.AreEqual(21.0, calculator.EndSequence(), "Multiplication result is not correct");
        }

        [TestMethod]
        public void Test_Division_Division()
        {
            var calculator = new Calculator();
            calculator.BeginSequence();
            var divideCommand1 = new DivideCommand(6.0);
            var divideCommand2 = new DivideCommand(2.0);
            divideCommand1.Execute(calculator);
            divideCommand2.Execute(calculator);
            Assert.AreEqual(3.0, calculator.EndSequence(), "Division result is not correct");
        }

        [TestMethod]
        public void Test_Addition_Subtraction()
        {
            var calculator = new Calculator();
            calculator.BeginSequence();
            var addCommand = new AddCommand(5.0);
            var subtractCommand = new SubtractCommand(3.0);
            addCommand.Execute(calculator);
            subtractCommand.Execute(calculator);
            Assert.AreEqual(2.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Subtraction_Addition()
        {
            var calculator = new Calculator();
            calculator.BeginSequence();
            var subtractCommand = new SubtractCommand(3.0);
            var addCommand = new AddCommand(5.0);
            subtractCommand.Execute(calculator);
            addCommand.Execute(calculator);
            Assert.AreEqual(2.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Addition_Multiplication()
        {
            var calculator = new Calculator();
            calculator.BeginSequence();
            var addCommand = new AddCommand(5.0);
            var multiplyCommand = new MultiplyCommand(3.0);
            addCommand.Execute(calculator);
            multiplyCommand.Execute(calculator);
            Assert.AreEqual(15.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Multiplication_Addition()
        {
            var calculator = new Calculator();
            calculator.BeginSequence();
            var multiplyCommand = new MultiplyCommand(3.0);
            var addCommand = new AddCommand(5.0);
            multiplyCommand.Execute(calculator);
            addCommand.Execute(calculator);
            Assert.AreEqual(8.0, calculator.EndSequence(), "Result is not correct");

        }

        [TestMethod]
        public void Test_Addition_Division()
        {
            var calculator = new Calculator();
            var addCommand = new AddCommand(8.0);
            var divideCommand = new DivideCommand(2.0);
            addCommand.Execute(calculator);
            divideCommand.Execute(calculator);
            Assert.AreEqual(4.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Division_Addition()
        {
            var calculator = new Calculator();
            var divideCommand = new DivideCommand(2.0);
            var addCommand = new AddCommand(8.0);
            divideCommand.Execute(calculator);
            addCommand.Execute(calculator);
            Assert.AreEqual(10.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Subtraction_Multiplication()
        {
            var calculator = new Calculator();
            var subtractCommand = new SubtractCommand(2.0);
            var multiplyCommand = new MultiplyCommand(3.0);
            subtractCommand.Execute(calculator);
            multiplyCommand.Execute(calculator);
            Assert.AreEqual(-6.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Multiplication_Subtraction()
        {
            var calculator = new Calculator();
            var multiplyCommand = new MultiplyCommand(4.0);
            var subtractCommand = new SubtractCommand(3.0);
            multiplyCommand.Execute(calculator);
            subtractCommand.Execute(calculator);
            Assert.AreEqual(1.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Subtraction_Division()
        {
            var calculator = new Calculator();
            var subtractCommand = new SubtractCommand(6.0);
            var divideCommand = new DivideCommand(2.0);
            subtractCommand.Execute(calculator);
            divideCommand.Execute(calculator);
            Assert.AreEqual(-3.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Division_Subtraction()
        {
            var calculator = new Calculator();
            var divideCommand = new DivideCommand(4.0);
            var subtractCommand = new SubtractCommand(3.0);
            divideCommand.Execute(calculator);
            subtractCommand.Execute(calculator);
            Assert.AreEqual(1.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Multiplication_Division()
        {
            var calculator = new Calculator();
            var multiplyCommand = new MultiplyCommand(8.0);
            var divideCommand = new DivideCommand(4.0);
            multiplyCommand.Execute(calculator);
            divideCommand.Execute(calculator);
            Assert.AreEqual(2.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Division_Multiplication()
        {
            var calculator = new Calculator();
            var divideCommand = new DivideCommand(4.0);
            var multiplyCommand = new MultiplyCommand(4.0);
            divideCommand.Execute(calculator);
            multiplyCommand.Execute(calculator);
            Assert.AreEqual(16.0, calculator.EndSequence(), "Result is not correct");
        }



        /// <summary>
        ///    3
        /// </summary>
        
        [TestMethod]
        public void Test_Addition_Addition_Addition()
        {
            var calculator = new Calculator();
            var addCommand1 = new AddCommand(2.0);
            var addCommand2 = new AddCommand(3.0);
            var addCommand3 = new AddCommand(4.0);
            addCommand1.Execute(calculator);
            addCommand2.Execute(calculator);
            addCommand3.Execute(calculator);
            Assert.AreEqual(9.0, calculator.EndSequence(), "Triple addition is not correct");
        }

        [TestMethod]
        public void Test_Subtraction_Subtraction_Subtraction()
        {
            var calculator = new Calculator();
            var subtractCommand1 = new SubtractCommand(2.0);
            var subtractCommand2 = new SubtractCommand(3.0);
            var subtractCommand3 = new SubtractCommand(4.0);
            subtractCommand1.Execute(calculator);
            subtractCommand2.Execute(calculator);
            subtractCommand3.Execute(calculator);
            Assert.AreEqual(-9.0, calculator.EndSequence(), "Triple subtraction is not correct");
        }

        [TestMethod]
        public void Test_Multiplication_Multiplication_Multiplication()
        {
            var calculator = new Calculator();
            var multiplyCommand1 = new MultiplyCommand(2.0);
            var multiplyCommand2 = new MultiplyCommand(3.0);
            var multiplyCommand3 = new MultiplyCommand(4.0);
            multiplyCommand1.Execute(calculator);
            multiplyCommand2.Execute(calculator);
            multiplyCommand3.Execute(calculator);
            Assert.AreEqual(24.0, calculator.EndSequence(), "Triple multiplication is not correct");
        }

        [TestMethod]
        public void Test_Division_Division_Division()
        {
            var calculator = new Calculator();
            var divideCommand1 = new DivideCommand(8.0);
            var divideCommand2 = new DivideCommand(2.0);
            var divideCommand3 = new DivideCommand(2.0);
            divideCommand1.Execute(calculator);
            divideCommand2.Execute(calculator);
            divideCommand3.Execute(calculator);
            Assert.AreEqual(2.0, calculator.EndSequence(), "Triple division is not correct");
        }

        [TestMethod]
        public void Test_Addition_Addition_Subtraction()
        {
            var calculator = new Calculator();
            var addCommand1 = new AddCommand(10.0);
            var addCommand2 = new AddCommand(5.0);
            var subtractCommand = new SubtractCommand(3.0);
            addCommand1.Execute(calculator);
            addCommand2.Execute(calculator);
            subtractCommand.Execute(calculator);
            Assert.AreEqual(12.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Addition_Subtraction_Subtraction()
        {
            var calculator = new Calculator();
            var addCommand = new AddCommand(10.0);
            var subtractCommand1 = new SubtractCommand(5.0);
            var subtractCommand2 = new SubtractCommand(3.0);
            addCommand.Execute(calculator);
            subtractCommand1.Execute(calculator);
            subtractCommand2.Execute(calculator);
            Assert.AreEqual(2.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Subtraction_Addition_Addition()
        {
            var calculator = new Calculator();
            var subtractCommand = new SubtractCommand(3.0);
            var addCommand1 = new AddCommand(10.0);
            var addCommand2 = new AddCommand(5.0);
            subtractCommand.Execute(calculator);
            addCommand1.Execute(calculator);
            addCommand2.Execute(calculator);
            Assert.AreEqual(12.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Subtraction_Subtraction_Addition()
        {
            var calculator = new Calculator();
            var subtractCommand1 = new SubtractCommand(5.0);
            var subtractCommand2 = new SubtractCommand(3.0);
            var addCommand = new AddCommand(10.0);
            subtractCommand1.Execute(calculator);
            subtractCommand2.Execute(calculator);
            addCommand.Execute(calculator);
            Assert.AreEqual(2.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Subtraction_Addition_Subtraction()
        {
            var calculator = new Calculator();
            var subtractCommand1 = new SubtractCommand(3.0);
            var addCommand = new AddCommand(5.0);
            var subtractCommand2 = new SubtractCommand(3.0);
            subtractCommand1.Execute(calculator);
            addCommand.Execute(calculator);
            subtractCommand2.Execute(calculator);
            Assert.AreEqual(-1.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Addition_Subtraction_Addition()
        {
            var calculator = new Calculator();
            var addCommand1 = new AddCommand(10.0);
            var subtractCommand = new SubtractCommand(3.0);
            var addCommand2 = new AddCommand(5.0);
            addCommand1.Execute(calculator);
            subtractCommand.Execute(calculator);
            addCommand2.Execute(calculator);
            Assert.AreEqual(12.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Addition_Addition_Multiplication()
        {
            var calculator = new Calculator();
            var addCommand1 = new AddCommand(3.0);
            var addCommand2 = new AddCommand(2.0);
            var multiplyCommand = new MultiplyCommand(4.0);
            addCommand1.Execute(calculator); 
            addCommand2.Execute(calculator);
            multiplyCommand.Execute(calculator);
            Assert.AreEqual(11.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Addition_Multiplication_Multiplication()
        {
            var calculator = new Calculator();
            var addCommand = new AddCommand(3.0);
            var multiplyCommand1 = new MultiplyCommand(2.0);
            var multiplyCommand2 = new MultiplyCommand(4.0);
            addCommand.Execute(calculator);
            multiplyCommand1.Execute(calculator);
            multiplyCommand2.Execute(calculator);
            Assert.AreEqual(24.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Multiplication_Addition_Addition()
        {
            var calculator = new Calculator();
            var multiplyCommand = new MultiplyCommand(2.0);
            var addCommand1 = new AddCommand(3.0);
            var addCommand2 = new AddCommand(2.0);
            addCommand1.Execute(calculator);
            addCommand2.Execute(calculator);
            multiplyCommand.Execute(calculator);
            Assert.AreEqual(7.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Multiplication_Multiplication_Addition()
        {
            var calculator = new Calculator();
            var multiplyCommand1 = new MultiplyCommand(4.0);
            var multiplyCommand2 = new MultiplyCommand(4.0);
            var addCommand = new AddCommand(2.0);
            multiplyCommand1.Execute(calculator);
            multiplyCommand2.Execute(calculator);
            addCommand.Execute(calculator);
            Assert.AreEqual(18.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Multiplication_Addition_Multiplication()
        {
            var calculator = new Calculator();
            var multiplyCommand1 = new MultiplyCommand(4.0);
            var addCommand = new AddCommand(3.0);
            var multiplyCommand2 = new MultiplyCommand(4.0);
            multiplyCommand1.Execute(calculator);
            addCommand.Execute(calculator);
            multiplyCommand2.Execute(calculator);
            Assert.AreEqual(16.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Addition_Multiplication_Addition()
        {
            var calculator = new Calculator();
            var addCommand1 = new AddCommand(3.0);
            var multiplyCommand = new MultiplyCommand(4.0);
            var addCommand2 = new AddCommand(2.0);
            addCommand1.Execute(calculator);
            multiplyCommand.Execute(calculator);
            addCommand2.Execute(calculator);
            Assert.AreEqual(14.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Addition_Addition_Division()
        {
            var calculator = new Calculator();
            var addCommand1 = new AddCommand(8.0);
            var addCommand2 = new AddCommand(4.0);
            var divideCommand = new DivideCommand(2.0);
            addCommand1.Execute(calculator);
            addCommand2.Execute(calculator);
            divideCommand.Execute(calculator);
            Assert.AreEqual(10.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Addition_Division_Division()
        {
            var calculator = new Calculator();
            var addCommand1 = new AddCommand(8.0);
            var divideCommand1 = new DivideCommand(2.0);
            var divideCommand2 = new DivideCommand(2.0);
            addCommand1.Execute(calculator);
            divideCommand1.Execute(calculator);
            divideCommand2.Execute(calculator);
            Assert.AreEqual(2.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Division_Addition_Addition()
        {
            var calculator = new Calculator();
            var divideCommand1 = new DivideCommand(8.0);
            var addCommand1 = new AddCommand(2.0);
            var addCommand2 = new AddCommand(2.0);
            divideCommand1.Execute(calculator);
            addCommand1.Execute(calculator);
            addCommand2.Execute(calculator);
            Assert.AreEqual(12.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Division_Division_Addition()
        {
            var calculator = new Calculator();
            var divideCommand1 = new DivideCommand(8.0);
            var divideCommand2 = new DivideCommand(2.0);
            var addCommand = new AddCommand(5.0);
            divideCommand1.Execute(calculator);
            divideCommand2.Execute(calculator);
            addCommand.Execute(calculator);
            Assert.AreEqual(9.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Division_Addition_Division()
        {
            var calculator = new Calculator();
            var divideCommand1 = new DivideCommand(5.0);
            var addCommand = new AddCommand(2.0);
            var divideCommand2 = new DivideCommand(2.0);
            divideCommand1.Execute(calculator);
            addCommand.Execute(calculator);
            divideCommand2.Execute(calculator);
            Assert.AreEqual(6.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Addition_Division_Addition()
        {
            var calculator = new Calculator();
            var addCommand1 = new AddCommand(8.0);
            var divideCommand = new DivideCommand(2.0);
            var addCommand2 = new AddCommand(2.0);
            addCommand1.Execute(calculator);
            divideCommand.Execute(calculator);
            addCommand2.Execute(calculator);
            Assert.AreEqual(6.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Subtraction_Subtraction_Multiplication()
        {
            var calculator = new Calculator();
            new SubtractCommand(10.0).Execute(calculator);
            new SubtractCommand(5.0).Execute(calculator);
            new MultiplyCommand(2.0).Execute(calculator);
            Assert.AreEqual(-20.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Subtraction_Multiplication_Multiplication()
        {
            var calculator = new Calculator();
            new SubtractCommand(6.0).Execute(calculator);
            new MultiplyCommand(2.0).Execute(calculator);
            new MultiplyCommand(3.0).Execute(calculator);
            Assert.AreEqual(-36.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Multiplication_Subtraction_Subtraction()
        {
            var calculator = new Calculator();
            new MultiplyCommand(5.0).Execute(calculator);
            new SubtractCommand(2.0).Execute(calculator);
            new SubtractCommand(3.0).Execute(calculator);
            Assert.AreEqual(0.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Multiplication_Multiplication_Subtraction()
        {
            var calculator = new Calculator();
            var multiplyCommand1 = new MultiplyCommand(3.0);
            var multiplyCommand2 = new MultiplyCommand(2.0);
            var subtractCommand = new SubtractCommand(4.0);
            multiplyCommand1.Execute(calculator);
            multiplyCommand2.Execute(calculator);
            subtractCommand.Execute(calculator);
            Assert.AreEqual(2.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Multiplication_Subtraction_Multiplication()
        {
            var calculator = new Calculator();
            var multiplyCommand1 = new MultiplyCommand(3.0);
            var subtractCommand = new SubtractCommand(1.0);
            var multiplyCommand2 = new MultiplyCommand(2.0);
            multiplyCommand1.Execute(calculator);
            subtractCommand.Execute(calculator);
            multiplyCommand2.Execute(calculator);
            Assert.AreEqual(1.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Subtraction_Multiplication_Subtraction()
        {
            var calculator = new Calculator();
            var subtractCommand1 = new SubtractCommand(10.0);
            var multiplyCommand = new MultiplyCommand(2.0);
            var subtractCommand2 = new SubtractCommand(5.0);
            subtractCommand1.Execute(calculator);
            multiplyCommand.Execute(calculator);
            subtractCommand2.Execute(calculator);
            Assert.AreEqual(-25.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Subtraction_Subtraction_Division()
        {
            var calculator = new Calculator();
            var subtractCommand1 = new SubtractCommand(10.0);
            var subtractCommand2 = new SubtractCommand(5.0);
            var divideCommand = new DivideCommand(2.0);
            subtractCommand1.Execute(calculator);
            subtractCommand2.Execute(calculator);
            divideCommand.Execute(calculator);
            Assert.AreEqual(-12.5, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Subtraction_Division_Division()
        {
            var calculator = new Calculator();
            var subtractCommand = new SubtractCommand(8.0);
            var divideCommand1 = new DivideCommand(2.0);
            var divideCommand2 = new DivideCommand(2.0);
            subtractCommand.Execute(calculator);
            divideCommand1.Execute(calculator);
            divideCommand2.Execute(calculator);
            Assert.AreEqual(-2.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Division_Subtraction_Subtraction()
        {
            var calculator = new Calculator();
            var divideCommand = new DivideCommand(10.0);
            var subtractCommand1 = new SubtractCommand(3.0);
            var subtractCommand2 = new SubtractCommand(2.0);
            divideCommand.Execute(calculator);
            subtractCommand1.Execute(calculator);
            subtractCommand2.Execute(calculator);
            Assert.AreEqual(5.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Division_Division_Subtraction()
        {
            var calculator = new Calculator();
            var divideCommand1 = new DivideCommand(20.0);
            var divideCommand2 = new DivideCommand(2.0);
            var subtractCommand = new SubtractCommand(5.0);
            divideCommand1.Execute(calculator);
            divideCommand2.Execute(calculator);
            subtractCommand.Execute(calculator);
            Assert.AreEqual(5.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Division_Subtraction_Division()
        {
            var calculator = new Calculator();
            var divideCommand1 = new DivideCommand(16.0);
            var subtractCommand = new SubtractCommand(2.0);
            var divideCommand2 = new DivideCommand(2.0);
            divideCommand1.Execute(calculator);
            subtractCommand.Execute(calculator);
            divideCommand2.Execute(calculator);
            Assert.AreEqual(15.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Multiplication_Multiplication_Division()
        {
            var calculator = new Calculator();
            new MultiplyCommand(3.0).Execute(calculator);
            new MultiplyCommand(2.0).Execute(calculator);
            new DivideCommand(4.0).Execute(calculator);
            Assert.AreEqual(1.5, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Multiplication_Division_Division()
        {
            var calculator = new Calculator();
            new MultiplyCommand(16.0).Execute(calculator);
            new DivideCommand(4.0).Execute(calculator);
            new DivideCommand(2.0).Execute(calculator);
            Assert.AreEqual(2.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Division_Multiplication_Multiplication()
        {
            var calculator = new Calculator();
            new DivideCommand(5.0).Execute(calculator);
            new MultiplyCommand(3.0).Execute(calculator);
            new MultiplyCommand(2.0).Execute(calculator);
            Assert.AreEqual(30.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Division_Division_Multiplication()
        {
            var calculator = new Calculator();
            new DivideCommand(40.0).Execute(calculator);
            new DivideCommand(4.0).Execute(calculator);
            new MultiplyCommand(2.0).Execute(calculator);
            Assert.AreEqual(20.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Division_Multiplication_Division()
        {
            var calculator = new Calculator();
            new DivideCommand(18.0).Execute(calculator);
            new MultiplyCommand(2.0).Execute(calculator);
            new DivideCommand(3.0).Execute(calculator);
            Assert.AreEqual(12.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Multiplication_Division_Multiplication()
        {
            var calculator = new Calculator();
            new MultiplyCommand(5.0).Execute(calculator);
            new DivideCommand(2.0).Execute(calculator);
            new MultiplyCommand(3.0).Execute(calculator);
            Assert.AreEqual(7.5, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Addition_Subtraction_Multiplication()
        {
            var calculator = new Calculator();
            new AddCommand(10.0).Execute(calculator);
            new SubtractCommand(5.0).Execute(calculator);
            new MultiplyCommand(2.0).Execute(calculator);
            Assert.AreEqual(0.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Addition_Multiplication_Subtraction()
        {
            var calculator = new Calculator();
            new AddCommand(7.0).Execute(calculator);
            new MultiplyCommand(3.0).Execute(calculator);
            new SubtractCommand(4.0).Execute(calculator);
            Assert.AreEqual(17.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Subtraction_Addition_Multiplication()
        {
            var calculator = new Calculator();
            new SubtractCommand(6.0).Execute(calculator);
            new AddCommand(4.0).Execute(calculator);
            new MultiplyCommand(3.0).Execute(calculator);
            Assert.AreEqual(6.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Subtraction_Multiplication_Addition()
        {
            var calculator = new Calculator();
            new SubtractCommand(5.0).Execute(calculator);
            new MultiplyCommand(2.0).Execute(calculator);
            new AddCommand(3.0).Execute(calculator);
            Assert.AreEqual(-7.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Multiplication_Subtraction_Addition()
        {
            var calculator = new Calculator();
            new MultiplyCommand(5.0).Execute(calculator);
            new SubtractCommand(2.0).Execute(calculator);
            new AddCommand(4.0).Execute(calculator);
            Assert.AreEqual(7.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Multiplication_Addition_Subtraction()
        {
            var calculator = new Calculator();
            new MultiplyCommand(3.0).Execute(calculator);
            new AddCommand(5.0).Execute(calculator);
            new SubtractCommand(2.0).Execute(calculator);
            Assert.AreEqual(6.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Addition_Subtraction_Division()
        {
            var calculator = new Calculator();
            new AddCommand(5.0).Execute(calculator);
            new SubtractCommand(8.0).Execute(calculator);
            new DivideCommand(2.0).Execute(calculator);
            Assert.AreEqual(1.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Addition_Division_Subtraction()
        {
            var calculator = new Calculator();
            new AddCommand(10.0).Execute(calculator);
            new DivideCommand(2.0).Execute(calculator);
            new SubtractCommand(3.0).Execute(calculator);
            Assert.AreEqual(2.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Subtraction_Addition_Division()
        {
            var calculator = new Calculator();
            new SubtractCommand(10.0).Execute(calculator);
            new AddCommand(20.0).Execute(calculator);
            new DivideCommand(2.0).Execute(calculator);
            Assert.AreEqual(0.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Subtraction_Division_Addition()
        {
            var calculator = new Calculator();
            new SubtractCommand(8.0).Execute(calculator);
            new DivideCommand(2.0).Execute(calculator);
            new AddCommand(6.0).Execute(calculator);
            Assert.AreEqual(2.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Division_Subtraction_Addition()
        {
            var calculator = new Calculator();
            new DivideCommand(12.0).Execute(calculator);
            new SubtractCommand(2.0).Execute(calculator);
            new AddCommand(1.0).Execute(calculator);
            Assert.AreEqual(11.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Division_Addition_Subtraction()
        {
            var calculator = new Calculator();
            new DivideCommand(16.0).Execute(calculator);
            new AddCommand(2.0).Execute(calculator);
            new SubtractCommand(4.0).Execute(calculator);
            Assert.AreEqual(14.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Addition_Multiplication_Division()
        {
            var calculator = new Calculator();
            new AddCommand(5.0).Execute(calculator);
            new MultiplyCommand(3.0).Execute(calculator);
            new DivideCommand(2.0).Execute(calculator);
            Assert.AreEqual(7.5, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Addition_Division_Multiplication()
        {
            var calculator = new Calculator();
            new AddCommand(8.0).Execute(calculator);
            new DivideCommand(2.0).Execute(calculator);
            new MultiplyCommand(3.0).Execute(calculator);
            Assert.AreEqual(12.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Multiplication_Addition_Division()
        {
            var calculator = new Calculator();
            new MultiplyCommand(4.0).Execute(calculator);
            new AddCommand(2.0).Execute(calculator);
            new DivideCommand(2.0).Execute(calculator);
            Assert.AreEqual(5.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Multiplication_Division_Addition()
        {
            var calculator = new Calculator();
            new MultiplyCommand(5.0).Execute(calculator);
            new DivideCommand(5.0).Execute(calculator);
            new AddCommand(3.0).Execute(calculator);
            Assert.AreEqual(4.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Division_Multiplication_Addition()
        {
            var calculator = new Calculator();
            new DivideCommand(10.0).Execute(calculator);
            new MultiplyCommand(2.0).Execute(calculator);
            new AddCommand(1.0).Execute(calculator);
            Assert.AreEqual(21.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Division_Addition_Multiplication()
        {
            var calculator = new Calculator();
            new DivideCommand(2.0).Execute(calculator);
            new AddCommand(5.0).Execute(calculator);
            new MultiplyCommand(2.0).Execute(calculator);
            Assert.AreEqual(12.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Subtraction_Multiplication_Division()
        {
            var calculator = new Calculator();
            new SubtractCommand(10.0).Execute(calculator);
            new MultiplyCommand(2.0).Execute(calculator);
            new DivideCommand(4.0).Execute(calculator);
            Assert.AreEqual(-5.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Subtraction_Division_Multiplication()
        {
            var calculator = new Calculator();
            new SubtractCommand(12.0).Execute(calculator);
            new DivideCommand(2.0).Execute(calculator);
            new MultiplyCommand(3.0).Execute(calculator);
            Assert.AreEqual(-18.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Multiplication_Subtraction_Division()
        {
            var calculator = new Calculator();
            new MultiplyCommand(6.0).Execute(calculator);
            new SubtractCommand(3.0).Execute(calculator);
            new DivideCommand(3.0).Execute(calculator);
            Assert.AreEqual(5.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Multiplication_Division_Subtraction()
        {
            var calculator = new Calculator();
            new MultiplyCommand(8.0).Execute(calculator);
            new DivideCommand(4.0).Execute(calculator);
            new SubtractCommand(1.0).Execute(calculator);
            Assert.AreEqual(1.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Division_Multiplication_Subtraction()
        {
            var calculator = new Calculator();
            new DivideCommand(2.0).Execute(calculator);
            new MultiplyCommand(2.0).Execute(calculator);
            new SubtractCommand(5.0).Execute(calculator);
            Assert.AreEqual(-1.0, calculator.EndSequence(), "Result is not correct");
        }

        [TestMethod]
        public void Test_Division_Subtraction_Multiplication()
        {
            var calculator = new Calculator();
            new DivideCommand(2.0).Execute(calculator);
            new SubtractCommand(4.0).Execute(calculator);
            new MultiplyCommand(1.0).Execute(calculator);
            Assert.AreEqual(-2.0, calculator.EndSequence(), "Result is not correct");
        }

    }
}
